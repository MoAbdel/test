import { base44 } from './base44Client';


export const RateQuote = base44.entities.RateQuote;

export const MortgageRate = base44.entities.MortgageRate;

export const MarketInsight = base44.entities.MarketInsight;



// auth sdk:
export const User = base44.auth;