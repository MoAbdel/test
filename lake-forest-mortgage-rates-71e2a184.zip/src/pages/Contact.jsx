
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Mail, MapPin, Clock, Shield, CheckCircle, ArrowRight } from "lucide-react";
import { RateQuote } from "@/api/entities";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    loan_amount: "",
    property_value: "",
    credit_score: "",
    loan_type: "",
    employment_status: "",
    annual_income: "",
    notes: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await RateQuote.create({
        ...formData,
        loan_amount: parseFloat(formData.loan_amount) || 0,
        property_value: parseFloat(formData.property_value) || 0,
        annual_income: parseFloat(formData.annual_income) || 0,
        status: "new"
      });
      setShowSuccess(true);
      setFormData({
        full_name: "",
        email: "",
        phone: "",
        loan_amount: "",
        property_value: "",
        credit_score: "",
        loan_type: "",
        employment_status: "",
        annual_income: "",
        notes: ""
      });
    } catch (error) {
      console.error("Error submitting contact form:", error);
    }
    
    setIsSubmitting(false);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen py-12 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-xl border-green-200">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Thank You!</h2>
              <p className="text-xl text-slate-600 mb-8">
                Your inquiry has been received. We'll review your information and contact you within 1 business hour to discuss your mortgage needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => setShowSuccess(false)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Submit Another Inquiry
                </Button>
                <a href="tel:(949) 579-2057">
                  <Button variant="outline">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Us Now
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Contact The Mortgage Hacker
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Ready to start your mortgage journey? Get in touch for a personalized consultation and competitive rate quote.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="shadow-lg border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center text-xl">
                  <Phone className="w-6 h-6 text-blue-600 mr-3" />
                  Get In Touch
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Phone className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-slate-900">(949) 579-2057</p>
                    <p className="text-sm text-slate-600">Call or text anytime</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-slate-900">mabdelfattah@nexamortgage.com</p>
                    <p className="text-sm text-slate-600">Quick email response</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-slate-900">Orange County, CA</p>
                    <p className="text-sm text-slate-600">Serving all of Orange County</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-slate-900">Available 24/7</p>
                    <p className="text-sm text-slate-600">Ready when you are</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center text-xl">
                  <Shield className="w-6 h-6 text-green-600 mr-3" />
                  The Mortgage Hacker Advantage
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Unbiased access to 200+ lenders</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Better rates & faster turnarounds</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">More approval options</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Tech-savvy and transparent process</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">No hidden fees, no red tape</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-xl border-slate-200">
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">
                  Get Your Free Rate Quote
                </CardTitle>
                <p className="text-slate-600">
                  Fill out the form below and we'll contact you within 1 business hour with your personalized rate quote.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="full_name" className="text-slate-700 font-medium">Full Name *</Label>
                      <Input
                        id="full_name"
                        value={formData.full_name}
                        onChange={(e) => handleInputChange("full_name", e.target.value)}
                        className="border-slate-300 mt-1"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-slate-700 font-medium">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        className="border-slate-300 mt-1"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone" className="text-slate-700 font-medium">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        className="border-slate-300 mt-1"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="loan_amount" className="text-slate-700 font-medium">Desired Loan Amount</Label>
                      <Input
                        id="loan_amount"
                        type="number"
                        value={formData.loan_amount}
                        onChange={(e) => handleInputChange("loan_amount", e.target.value)}
                        placeholder="500000"
                        className="border-slate-300 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="property_value" className="text-slate-700 font-medium">Property Value</Label>
                      <Input
                        id="property_value"
                        type="number"
                        value={formData.property_value}
                        onChange={(e) => handleInputChange("property_value", e.target.value)}
                        placeholder="625000"
                        className="border-slate-300 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="credit_score" className="text-slate-700 font-medium">Credit Score Range</Label>
                      <Select value={formData.credit_score} onValueChange={(value) => handleInputChange("credit_score", value)}>
                        <SelectTrigger className="border-slate-300 mt-1">
                          <SelectValue placeholder="Select credit score range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="excellent">Excellent (740+)</SelectItem>
                          <SelectItem value="good">Good (680-739)</SelectItem>
                          <SelectItem value="fair">Fair (620-679)</SelectItem>
                          <SelectItem value="needs_improvement">Needs Improvement (Below 620)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="loan_type" className="text-slate-700 font-medium">Loan Type Interest</Label>
                      <Select value={formData.loan_type} onValueChange={(value) => handleInputChange("loan_type", value)}>
                        <SelectTrigger className="border-slate-300 mt-1">
                          <SelectValue placeholder="Select loan type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conventional">Conventional</SelectItem>
                          <SelectItem value="fha">FHA</SelectItem>
                          <SelectItem value="va">VA</SelectItem>
                          <SelectItem value="jumbo">Jumbo</SelectItem>
                          <SelectItem value="refinance">Refinance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="employment_status" className="text-slate-700 font-medium">Employment Status</Label>
                      <Select value={formData.employment_status} onValueChange={(value) => handleInputChange("employment_status", value)}>
                        <SelectTrigger className="border-slate-300 mt-1">
                          <SelectValue placeholder="Select employment status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="employed">Employed</SelectItem>
                          <SelectItem value="self_employed">Self-Employed</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="annual_income" className="text-slate-700 font-medium">Annual Income</Label>
                      <Input
                        id="annual_income"
                        type="number"
                        value={formData.annual_income}
                        onChange={(e) => handleInputChange("annual_income", e.target.value)}
                        placeholder="100000"
                        className="border-slate-300 mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="notes" className="text-slate-700 font-medium">Additional Information</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => handleInputChange("notes", e.target.value)}
                      placeholder="Tell us about your timeline, specific needs, or any questions you have..."
                      className="border-slate-300 mt-1 h-24"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 text-lg font-semibold"
                  >
                    {isSubmitting ? (
                      "Submitting..."
                    ) : (
                      <>
                        Get My Free Rate Quote
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 text-sm text-slate-600">
                      <Shield className="w-4 h-4 text-green-600" />
                      <span>Your information is secure and will never be shared. NMLS #123456</span>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
