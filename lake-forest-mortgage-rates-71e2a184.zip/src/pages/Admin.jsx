
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Settings, Save, Plus, Edit, Trash2, RefreshCw, BarChart } from "lucide-react";
import { MortgageRate } from "@/api/entities";
import { MarketInsight } from "@/api/entities";

export default function AdminPage() {
  const [rates, setRates] = useState([]);
  const [editingRate, setEditingRate] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    loan_type: "",
    rate: "",
    apr: "",
    display_name: "",
    min_down_payment: "",
    is_active: true,
    effective_date: new Date().toISOString().split('T')[0]
  });

  const [insights, setInsights] = useState([]);
  const [editingInsight, setEditingInsight] = useState(null);
  const [showInsightForm, setShowInsightForm] = useState(false);
  const [insightFormData, setInsightFormData] = useState({
    metric: "",
    value: "",
    change: "",
    trend: "stable",
    description: "",
    display_order: 0
  });

  const loanTypeOptions = [
    { value: "30_year_fixed", label: "30-Year Fixed Conventional" },
    { value: "15_year_fixed", label: "15-Year Fixed Conventional" },
    { value: "fha_30_year", label: "FHA 30-Year Fixed" },
    { value: "va_30_year", label: "VA 30-Year Fixed" },
    { value: "jumbo_30_year", label: "Jumbo 30-Year Fixed" },
    { value: "5_1_arm", label: "5/1 ARM" },
    { value: "7_1_arm", label: "7/1 ARM" }
  ];

  useEffect(() => {
    loadRates();
    loadInsights();
  }, []);

  const loadRates = async () => {
    try {
      const fetchedRates = await MortgageRate.list('-effective_date');
      setRates(fetchedRates);
    } catch (error) {
      console.error("Error loading rates:", error);
    }
  };

  const loadInsights = async () => {
    try {
      const fetchedInsights = await MarketInsight.list('display_order');
      setInsights(fetchedInsights);
    } catch (error) {
      console.error("Error loading insights:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const rateData = {
        ...formData,
        rate: parseFloat(formData.rate),
        apr: parseFloat(formData.apr)
      };

      if (editingRate) {
        await MortgageRate.update(editingRate.id, rateData);
      } else {
        await MortgageRate.create(rateData);
      }
      
      resetForm();
      loadRates();
    } catch (error) {
      console.error("Error saving rate:", error);
    }
    
    setIsLoading(false);
  };

  const handleEdit = (rate) => {
    setEditingRate(rate);
    setFormData({
      loan_type: rate.loan_type,
      rate: rate.rate.toString(),
      apr: rate.apr.toString(),
      display_name: rate.display_name,
      min_down_payment: rate.min_down_payment || "",
      is_active: rate.is_active,
      effective_date: rate.effective_date || new Date().toISOString().split('T')[0]
    });
    setShowForm(true);
  };

  const handleDelete = async (rateId) => {
    if (window.confirm("Are you sure you want to delete this rate?")) {
      try {
        await MortgageRate.delete(rateId);
        loadRates();
      } catch (error) {
        console.error("Error deleting rate:", error);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      loan_type: "",
      rate: "",
      apr: "",
      display_name: "",
      min_down_payment: "",
      is_active: true,
      effective_date: new Date().toISOString().split('T')[0]
    });
    setEditingRate(null);
    setShowForm(false);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleInsightInputChange = (field, value) => {
    setInsightFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const resetInsightForm = () => {
    setInsightFormData({
      metric: "",
      value: "",
      change: "",
      trend: "stable",
      description: "",
      display_order: 0
    });
    setEditingInsight(null);
    setShowInsightForm(false);
  };

  const handleInsightEdit = (insight) => {
    setEditingInsight(insight);
    setInsightFormData({
      metric: insight.metric,
      value: insight.value,
      change: insight.change,
      trend: insight.trend,
      description: insight.description,
      display_order: insight.display_order
    });
    setShowInsightForm(true);
  };
  
  const handleInsightDelete = async (insightId) => {
    if (window.confirm("Are you sure you want to delete this insight?")) {
      try {
        await MarketInsight.delete(insightId);
        loadInsights();
      } catch (error) {
        console.error("Error deleting insight:", error);
      }
    }
  };

  const handleInsightSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const insightData = {
        ...insightFormData,
        display_order: Number(insightFormData.display_order)
      };

      if (editingInsight) {
        await MarketInsight.update(editingInsight.id, insightData);
      } else {
        await MarketInsight.create(insightData);
      }
      
      resetInsightForm();
      loadInsights();
    } catch (error) {
      console.error("Error saving insight:", error);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen py-8 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 flex items-center">
                <BarChart className="w-8 h-8 text-blue-600 mr-3" />
                Rate Management Dashboard
              </h1>
              <p className="text-slate-600 mt-2">Manage current mortgage rates displayed on your website</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button onClick={() => loadRates()} variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button 
                onClick={() => setShowForm(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add New Rate
              </Button>
            </div>
          </div>
        </div>

        {/* Rate Form */}
        {showForm && (
          <Card className="mb-8 shadow-lg border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center">
                {editingRate ? <Edit className="w-5 h-5 mr-2" /> : <Plus className="w-5 h-5 mr-2" />}
                {editingRate ? "Edit Rate" : "Add New Rate"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="loan_type">Loan Type</Label>
                    <Select 
                      value={formData.loan_type} 
                      onValueChange={(value) => handleInputChange("loan_type", value)}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select loan type" />
                      </SelectTrigger>
                      <SelectContent>
                        {loanTypeOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="display_name">Display Name</Label>
                    <Input
                      id="display_name"
                      value={formData.display_name}
                      onChange={(e) => handleInputChange("display_name", e.target.value)}
                      placeholder="e.g., 30-Year Fixed"
                      className="mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="rate">Interest Rate (%)</Label>
                    <Input
                      id="rate"
                      type="number"
                      step="0.001"
                      value={formData.rate}
                      onChange={(e) => handleInputChange("rate", e.target.value)}
                      placeholder="6.875"
                      className="mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="apr">APR (%)</Label>
                    <Input
                      id="apr"
                      type="number"
                      step="0.001"
                      value={formData.apr}
                      onChange={(e) => handleInputChange("apr", e.target.value)}
                      placeholder="6.920"
                      className="mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="min_down_payment">Minimum Down Payment</Label>
                    <Input
                      id="min_down_payment"
                      value={formData.min_down_payment}
                      onChange={(e) => handleInputChange("min_down_payment", e.target.value)}
                      placeholder="3% or 0%"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="effective_date">Effective Date</Label>
                    <Input
                      id="effective_date"
                      type="date"
                      value={formData.effective_date}
                      onChange={(e) => handleInputChange("effective_date", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="is_active"
                    checked={formData.is_active}
                    onChange={(e) => handleInputChange("is_active", e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="is_active">Display this rate on website</Label>
                </div>

                <div className="flex justify-end space-x-3">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
                    {isLoading ? "Saving..." : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        {editingRate ? "Update Rate" : "Save Rate"}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Current Rates Table */}
        <Card className="shadow-lg border-slate-200">
          <CardHeader>
            <CardTitle>Current Rates</CardTitle>
            <p className="text-sm text-slate-600">
              These are the rates currently displayed on your website
            </p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-4 font-semibold">Loan Type</th>
                    <th className="text-center py-3 px-4 font-semibold">Rate</th>
                    <th className="text-center py-3 px-4 font-semibold">APR</th>
                    <th className="text-center py-3 px-4 font-semibold">Min Down</th>
                    <th className="text-center py-3 px-4 font-semibold">Status</th>
                    <th className="text-center py-3 px-4 font-semibold">Effective Date</th>
                    <th className="text-center py-3 px-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rates.map((rate, index) => (
                    <tr key={rate.id} className={`border-b border-slate-100 ${index % 2 === 0 ? 'bg-slate-50' : ''}`}>
                      <td className="py-3 px-4 font-medium">{rate.display_name}</td>
                      <td className="text-center py-3 px-4 text-2xl font-bold text-green-600">
                        {rate.rate}%
                      </td>
                      <td className="text-center py-3 px-4">{rate.apr}%</td>
                      <td className="text-center py-3 px-4">{rate.min_down_payment || "N/A"}</td>
                      <td className="text-center py-3 px-4">
                        <Badge className={rate.is_active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                          {rate.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        {rate.effective_date ? new Date(rate.effective_date).toLocaleDateString() : "N/A"}
                      </td>
                      <td className="text-center py-3 px-4">
                        <div className="flex justify-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(rate)}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(rate.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {rates.length === 0 && (
                    <tr>
                      <td colSpan="7" className="text-center py-8 text-slate-500">
                        No rates found. Add your first rate above.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{rates.filter(r => r.is_active).length}</div>
              <div className="text-sm text-slate-600">Active Rates</div>
            </CardContent>
          </Card>
          
          <Card className="border-blue-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{rates.length}</div>
              <div className="text-sm text-slate-600">Total Rates</div>
            </CardContent>
          </Card>
          
          <Card className="border-orange-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {rates.filter(r => r.effective_date === new Date().toISOString().split('T')[0]).length}
              </div>
              <div className="text-sm text-slate-600">Updated Today</div>
            </CardContent>
          </Card>
        </div>

        {/* Market Insights Management */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 flex items-center">
                <BarChart className="w-8 h-8 text-green-600 mr-3" />
                Market Insights Management
              </h2>
              <p className="text-slate-600 mt-2">Manage market data cards on the homepage</p>
            </div>
            <Button
              onClick={() => setShowInsightForm(true)}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Insight
            </Button>
          </div>

          {/* Insight Form */}
          {showInsightForm && (
            <Card className="mb-8 shadow-lg border-green-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  {editingInsight ? <Edit className="w-5 h-5 mr-2" /> : <Plus className="w-5 h-5 mr-2" />}
                  {editingInsight ? "Edit Insight" : "Add New Insight"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleInsightSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="metric">Metric Name</Label>
                      <Input id="metric" value={insightFormData.metric} onChange={(e) => handleInsightInputChange("metric", e.target.value)} placeholder="e.g., Median Home Price" className="mt-1" required />
                    </div>
                    <div>
                      <Label htmlFor="value">Metric Value</Label>
                      <Input id="value" value={insightFormData.value} onChange={(e) => handleInsightInputChange("value", e.target.value)} placeholder="e.g., $1,285,000" className="mt-1" required />
                    </div>
                    <div>
                      <Label htmlFor="change">Change Value</Label>
                      <Input id="change" value={insightFormData.change} onChange={(e) => handleInsightInputChange("change", e.target.value)} placeholder="e.g., +3.2%" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="trend">Trend</Label>
                      <Select value={insightFormData.trend} onValueChange={(value) => handleInsightInputChange("trend", value)}>
                        <SelectTrigger className="mt-1"><SelectValue placeholder="Select trend" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="up">Up</SelectItem>
                          <SelectItem value="down">Down</SelectItem>
                          <SelectItem value="stable">Stable</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Input id="description" value={insightFormData.description} onChange={(e) => handleInsightInputChange("description", e.target.value)} placeholder="e.g., Year over year" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="display_order">Display Order</Label>
                      <Input id="display_order" type="number" value={insightFormData.display_order} onChange={(e) => handleInsightInputChange("display_order", e.target.value)} className="mt-1" />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-3">
                    <Button type="button" variant="outline" onClick={resetInsightForm}>Cancel</Button>
                    <Button type="submit" disabled={isLoading} className="bg-green-600 hover:bg-green-700">
                      {isLoading ? "Saving..." : <><Save className="w-4 h-4 mr-2" />{editingInsight ? "Update Insight" : "Save Insight"}</>}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
          
          {/* Current Insights Table */}
          <Card className="shadow-lg border-slate-200">
            <CardHeader><CardTitle>Current Insights</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="text-left py-3 px-4 font-semibold">Order</th>
                      <th className="text-left py-3 px-4 font-semibold">Metric</th>
                      <th className="text-left py-3 px-4 font-semibold">Value</th>
                      <th className="text-center py-3 px-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {insights.map((insight, index) => (
                      <tr key={insight.id} className={`border-b border-slate-100 ${index % 2 === 0 ? 'bg-slate-50' : ''}`}>
                        <td className="py-3 px-4">{insight.display_order}</td>
                        <td className="py-3 px-4 font-medium">{insight.metric}</td>
                        <td className="py-3 px-4">{insight.value}</td>
                        <td className="text-center py-3 px-4">
                          <div className="flex justify-center space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleInsightEdit(insight)}><Edit className="w-3 h-3" /></Button>
                            <Button variant="outline" size="sm" onClick={() => handleInsightDelete(insight.id)} className="text-red-600 hover:text-red-700"><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {insights.length === 0 && (
                      <tr><td colSpan="4" className="text-center py-8 text-slate-500">No insights found.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  );
}
