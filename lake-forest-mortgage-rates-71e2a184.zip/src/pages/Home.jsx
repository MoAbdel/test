import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingDown, Calculator, Users, Award, Star, ArrowRight, Home, DollarSign, Clock, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import HeroSection from "../components/home/HeroSection";
import RateDisplay from "../components/home/RateDisplay";
import QuickQuote from "../components/home/QuickQuote";
import WhyChooseUs from "../components/home/WhyChooseUs";
import LocalMarketInsights from "../components/home/LocalMarketInsights";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <RateDisplay />
      <QuickQuote />
      <LocalMarketInsights />
      <WhyChooseUs />
      
      {/* Final CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Get your personalized rate quote in under 60 seconds
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Calculator")}>
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-3 text-lg font-semibold">
                <Calculator className="w-5 h-5 mr-2" />
                Calculate Rates
              </Button>
            </Link>
            <a href="tel:(949) 555-0123">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 text-lg font-semibold">
                Call Now: (949) 555-0123
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}