

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Calculator, FileText, Phone, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const navigationItems = [
  {
    title: "Home",
    url: createPageUrl("Home"),
    icon: Home,
  },
  {
    title: "Rate Calculator",
    url: createPageUrl("Calculator"),
    icon: Calculator,
  },
  {
    title: "Loan Programs",
    url: createPageUrl("Programs"),
    icon: FileText,
  },
  {
    title: "Contact",
    url: createPageUrl("Contact"),
    icon: Phone,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-24">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-2 sm:gap-4">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/9398aadde_zx.PNG" 
                alt="Mo The Broker Headshot" 
                className="h-16 w-16 sm:h-20 sm:w-20 rounded-full object-cover object-[30%_15%]"
              />
              <span className="text-xl md:text-2xl font-bold text-slate-800">Mo The Broker</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navigationItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                    location.pathname === item.url
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-slate-700 hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.title}</span>
                </Link>
              ))}
            </nav>

            {/* CTA Button */}
            <div className="hidden md:flex items-center space-x-4">
              <a href="tel:(949) 579-2057" className="text-blue-600 font-medium hover:text-blue-700">
                (949) 579-2057
              </a>
              <Link to={createPageUrl("Contact")}>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6">
                  Get Quote
                </Button>
              </Link>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-200">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigationItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-base font-medium ${
                    location.pathname === item.url
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-slate-700 hover:text-blue-600 hover:bg-slate-50'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.title}</span>
                </Link>
              ))}
              <div className="pt-4 border-t border-slate-200 mt-4">
                <a href="tel:(949) 579-2057" className="block px-3 py-2 text-blue-600 font-medium">
                  (949) 579-2057
                </a>
                <Link to={createPageUrl("Contact")} className="block px-3 py-2">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                    Get Quote
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-4 mb-4">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c9462d169_MinimalistHouseLineRealEstateLogo.png" 
                  alt="Mo The Broker" 
                  className="h-32 w-auto filter invert"
                />
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/8a7d4bd11_Untitleddesign9.png" 
                  alt="Equal Housing Opportunity" 
                  className="h-20 w-auto"
                />
              </div>
              <p className="text-slate-400 mb-4">
                Your trusted local mortgage broker serving all of Orange County. 
                I'm committed to finding you the best rates and loan programs available.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-slate-400">
                {navigationItems.map((item) => (
                  <li key={item.title}>
                    <Link to={item.url} className="hover:text-white transition-colors duration-200">
                      {item.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
              <ul className="space-y-2 text-slate-400">
                <li>📞 (949) 579-2057</li>
                <li>📧 mabdelfattah@nexamortgage.com</li>
                <li>📍 Orange County, CA</li>
                <li>🕒 Available 24/7</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; {new Date().getFullYear()} Mo The Broker. All rights reserved.</p>
            <p>NMLS# 1426884</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

