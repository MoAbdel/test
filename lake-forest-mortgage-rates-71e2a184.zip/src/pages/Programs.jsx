
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Home, Users, Star, Building, ArrowRight, CheckCircle, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const loanPrograms = [
  {
    title: "Conventional Loans",
    icon: Home,
    rate: "6.875%",
    minDown: "3%",
    description: "Traditional financing with competitive rates for borrowers with good credit.",
    features: [
      "Down payments as low as 3%",
      "No mortgage insurance with 20% down",
      "Loan amounts up to $766,550",
      "Fixed and adjustable rate options",
      "Can be used for primary residence, second homes, and investment properties"
    ],
    ideal: "Borrowers with good credit (620+) and stable income",
    color: "blue"
  },
  {
    title: "FHA Loans",
    icon: Users,
    rate: "6.500%",
    minDown: "3.5%",
    description: "Government-backed loans perfect for first-time buyers with lower credit scores.",
    features: [
      "Down payment as low as 3.5%",
      "Credit scores as low as 580",
      "Gift funds allowed for down payment",
      "Assumable mortgages",
      "Streamline refinancing available"
    ],
    ideal: "First-time buyers and borrowers with lower credit scores",
    color: "green"
  },
  {
    title: "VA Loans",
    icon: Star,
    rate: "6.375%",
    minDown: "0%",
    description: "Exclusive benefits for military veterans, active duty, and eligible spouses.",
    features: [
      "No down payment required",
      "No mortgage insurance",
      "No prepayment penalties",
      "Competitive interest rates",
      "Can be reused multiple times"
    ],
    ideal: "Veterans, active military, and eligible surviving spouses",
    color: "purple"
  },
  {
    title: "Jumbo Loans",
    icon: Building,
    rate: "7.125%",
    minDown: "10%",
    description: "Financing for luxury homes above conventional loan limits in Orange County.",
    features: [
      "Loan amounts above $766,550",
      "Competitive rates for high-value properties",
      "Down payments typically 10-20%",
      "Flexible underwriting guidelines",
      "Portfolio lending options"
    ],
    ideal: "Luxury home buyers with strong financial profiles",
    color: "orange"
  }
];

const specialPrograms = [
  {
    title: "First-Time Home Buyer Programs",
    description: "Special assistance programs for first-time buyers in Orange County",
    benefits: ["Down payment assistance", "Reduced fees", "Educational resources", "Preferred rates"]
  },
  {
    title: "Bank Statement Loans",
    description: "Alternative documentation for self-employed borrowers",
    benefits: ["No tax returns required", "Bank statements for income verification", "Quick approval process", "Competitive rates"]
  },
  {
    title: "Asset-Based Lending",
    description: "Qualify based on assets rather than traditional income",
    benefits: ["Asset depletion calculations", "Retirement account qualification", "Investment property financing", "High net worth solutions"]
  }
];

export default function ProgramsPage() {
  const getColorClasses = (color) => {
    const colors = {
      blue: "text-blue-600 bg-blue-100",
      green: "text-green-600 bg-green-100", 
      purple: "text-purple-600 bg-purple-100",
      orange: "text-orange-600 bg-orange-100"
    };
    return colors[color] || "text-blue-600 bg-blue-100";
  };

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Orange County Mortgage Loan Programs
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Choose from a comprehensive range of loan programs designed to meet your unique needs. 
            From first-time buyers to luxury home purchases, we have the right solution for you.
          </p>
        </div>

        {/* Main Loan Programs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {loanPrograms.map((program, index) => (
            <Card key={index} className="hover:shadow-xl transition-all duration-300 border-slate-200">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(program.color)}`}>
                      <program.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl text-slate-900">{program.title}</CardTitle>
                      <p className="text-slate-600 mt-1">{program.description}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 mt-4">
                  <Badge className="bg-green-100 text-green-800">
                    Rate: {program.rate}
                  </Badge>
                  <Badge variant="outline">
                    Min Down: {program.minDown}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Key Features:</h4>
                  <ul className="space-y-2">
                    {program.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-slate-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-slate-50 rounded-lg p-4">
                  <h4 className="font-semibold text-slate-900 mb-1">Ideal For:</h4>
                  <p className="text-sm text-slate-600">{program.ideal}</p>
                </div>
                
                <Link to={createPageUrl("Calculator")}>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Calculate Payment
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Special Programs */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-4">
              Specialized Loan Programs
            </h2>
            <p className="text-lg text-slate-600">
              Additional financing options for unique situations and borrower needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {specialPrograms.map((program, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 border-slate-200">
                <CardHeader>
                  <CardTitle className="text-lg text-slate-900">{program.title}</CardTitle>
                  <p className="text-slate-600 text-sm">{program.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {program.benefits.map((benefit, benefitIndex) => (
                      <li key={benefitIndex} className="flex items-center space-x-2 text-sm">
                        <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                        <span className="text-slate-600">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Comparison Table */}
        <div className="mb-16">
          <Card className="shadow-lg border-slate-200">
            <CardHeader>
              <CardTitle className="text-2xl text-slate-900 text-center">
                Quick Comparison Guide
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="text-left py-3 px-4 font-semibold text-slate-900">Program</th>
                      <th className="text-center py-3 px-4 font-semibold text-slate-900">Min Down</th>
                      <th className="text-center py-3 px-4 font-semibold text-slate-900">Min Credit</th>
                      <th className="text-center py-3 px-4 font-semibold text-slate-900">Max Loan</th>
                      <th className="text-center py-3 px-4 font-semibold text-slate-900">Current Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-100">
                      <td className="py-3 px-4 font-medium text-slate-900">Conventional</td>
                      <td className="text-center py-3 px-4">3%</td>
                      <td className="text-center py-3 px-4">620</td>
                      <td className="text-center py-3 px-4">$766,550</td>
                      <td className="text-center py-3 px-4 font-semibold text-green-600">6.875%</td>
                    </tr>
                    <tr className="border-b border-slate-100">
                      <td className="py-3 px-4 font-medium text-slate-900">FHA</td>
                      <td className="text-center py-3 px-4">3.5%</td>
                      <td className="text-center py-3 px-4">580</td>
                      <td className="text-center py-3 px-4">$498,257</td>
                      <td className="text-center py-3 px-4 font-semibold text-green-600">6.500%</td>
                    </tr>
                    <tr className="border-b border-slate-100">
                      <td className="py-3 px-4 font-medium text-slate-900">VA</td>
                      <td className="text-center py-3 px-4">0%</td>
                      <td className="text-center py-3 px-4">No Min</td>
                      <td className="text-center py-3 px-4">$766,550</td>
                      <td className="text-center py-3 px-4 font-semibold text-green-600">6.375%</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-slate-900">Jumbo</td>
                      <td className="text-center py-3 px-4">10%</td>
                      <td className="text-center py-3 px-4">700</td>
                      <td className="text-center py-3 px-4">$3M+</td>
                      <td className="text-center py-3 px-4 font-semibold text-green-600">7.125%</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto shadow-xl border-blue-200">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">
                Find Your Perfect Loan Program
              </h3>
              <p className="text-slate-600 mb-6">
                Not sure which program is right for you? Let's discuss your goals and find the best financing solution for your situation.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={createPageUrl("Contact")}>
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8">
                    Get Personalized Recommendation
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                
                <Link to={createPageUrl("Calculator")}>
                  <Button size="lg" variant="outline" className="px-8">
                    Compare Payments
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
