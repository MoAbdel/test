import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, DollarSign, ArrowRight, Home, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import MortgageCalculator from "../components/calculator/MortgageCalculator";
import AffordabilityCalculator from "../components/calculator/AffordabilityCalculator";
import RefinanceCalculator from "../components/calculator/RefinanceCalculator";

export default function CalculatorPage() {
  const [activeCalculator, setActiveCalculator] = useState("mortgage");

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Mortgage Rate Calculators
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Use our comprehensive calculators to estimate payments, affordability, and potential savings. 
            All calculations are based on current Orange County market rates.
          </p>
        </div>

        {/* Calculator Selector */}
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
          <Button
            variant={activeCalculator === "mortgage" ? "default" : "outline"}
            onClick={() => setActiveCalculator("mortgage")}
            className="flex items-center gap-2"
          >
            <Calculator className="w-4 h-4" />
            Payment Calculator
          </Button>
          <Button
            variant={activeCalculator === "affordability" ? "default" : "outline"}
            onClick={() => setActiveCalculator("affordability")}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            Affordability Calculator
          </Button>
          <Button
            variant={activeCalculator === "refinance" ? "default" : "outline"}
            onClick={() => setActiveCalculator("refinance")}
            className="flex items-center gap-2"
          >
            <TrendingUp className="w-4 h-4" />
            Refinance Calculator
          </Button>
        </div>

        {/* Calculator Components */}
        {activeCalculator === "mortgage" && <MortgageCalculator />}
        {activeCalculator === "affordability" && <AffordabilityCalculator />}
        {activeCalculator === "refinance" && <RefinanceCalculator />}

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <Card className="max-w-2xl mx-auto shadow-lg border-blue-200">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">
                Ready to Get Your Official Rate Quote?
              </h3>
              <p className="text-slate-600 mb-6">
                These calculators provide estimates. For your actual rate and terms, 
                let's discuss your specific situation and goals.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={createPageUrl("Contact")}>
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8">
                    <Calculator className="w-5 h-5 mr-2" />
                    Get Official Quote
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                
                <a href="tel:(949) 555-0123">
                  <Button size="lg" variant="outline" className="px-8">
                    Call (949) 555-0123
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}