import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, DollarSign, Calculator } from "lucide-react";

export default function RefinanceCalculator() {
  const [currentBalance, setCurrentBalance] = useState(400000);
  const [currentRate, setCurrentRate] = useState(7.5);
  const [currentPayment, setCurrentPayment] = useState(2800);
  const [newRate, setNewRate] = useState(6.875);
  const [newTerm, setNewTerm] = useState(30);
  const [closingCosts, setClosingCosts] = useState(5000);
  const [cashOut, setCashOut] = useState(0);
  const [homeValue, setHomeValue] = useState(500000);

  const [results, setResults] = useState({
    newPayment: 0,
    monthlySavings: 0,
    totalSavings: 0,
    breakEvenMonths: 0,
    loanToValue: 0,
    totalNewLoan: 0
  });

  useEffect(() => {
    calculateRefinance();
  }, [currentBalance, currentRate, currentPayment, newRate, newTerm, closingCosts, cashOut, homeValue]);

  const calculateRefinance = () => {
    const totalNewLoan = currentBalance + cashOut;
    const monthlyRate = (newRate / 100) / 12;
    const numberOfPayments = newTerm * 12;

    let newPayment = 0;
    if (monthlyRate > 0) {
      newPayment = totalNewLoan * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    } else {
      newPayment = totalNewLoan / numberOfPayments;
    }

    const monthlySavings = currentPayment - newPayment;
    const totalSavings = monthlySavings * numberOfPayments - closingCosts;
    const breakEvenMonths = monthlySavings > 0 ? closingCosts / monthlySavings : 0;
    const loanToValue = (totalNewLoan / homeValue) * 100;

    setResults({
      newPayment,
      monthlySavings,
      totalSavings,
      breakEvenMonths,
      loanToValue,
      totalNewLoan
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Form */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Calculator className="w-6 h-6 text-blue-600 mr-3" />
            Current & New Loan Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-slate-50 rounded-lg p-4">
            <h4 className="font-semibold text-slate-900 mb-3">Current Loan Information</h4>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="currentBalance" className="text-slate-700 font-medium">Current Loan Balance</Label>
                <Input
                  id="currentBalance"
                  type="number"
                  value={currentBalance}
                  onChange={(e) => setCurrentBalance(Number(e.target.value))}
                  className="border-slate-300 mt-1"
                />
              </div>
              <div>
                <Label htmlFor="currentRate" className="text-slate-700 font-medium">Current Interest Rate (%)</Label>
                <Input
                  id="currentRate"
                  type="number"
                  step="0.001"
                  value={currentRate}
                  onChange={(e) => setCurrentRate(Number(e.target.value))}
                  className="border-slate-300 mt-1"
                />
              </div>
              <div>
                <Label htmlFor="currentPayment" className="text-slate-700 font-medium">Current Monthly Payment</Label>
                <Input
                  id="currentPayment"
                  type="number"
                  value={currentPayment}
                  onChange={(e) => setCurrentPayment(Number(e.target.value))}
                  className="border-slate-300 mt-1"
                />
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-semibold text-slate-900 mb-3">New Loan Information</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="newRate" className="text-slate-700 font-medium">New Interest Rate (%)</Label>
                <Input
                  id="newRate"
                  type="number"
                  step="0.001"
                  value={newRate}
                  onChange={(e) => setNewRate(Number(e.target.value))}
                  className="border-slate-300 mt-1"
                />
              </div>
              <div>
                <Label htmlFor="newTerm" className="text-slate-700 font-medium">New Loan Term</Label>
                <Select value={newTerm.toString()} onValueChange={(value) => setNewTerm(Number(value))}>
                  <SelectTrigger className="border-slate-300 mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 Years</SelectItem>
                    <SelectItem value="20">20 Years</SelectItem>
                    <SelectItem value="25">25 Years</SelectItem>
                    <SelectItem value="30">30 Years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="homeValue" className="text-slate-700 font-medium">Current Home Value</Label>
              <Input
                id="homeValue"
                type="number"
                value={homeValue}
                onChange={(e) => setHomeValue(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="closingCosts" className="text-slate-700 font-medium">Estimated Closing Costs</Label>
              <Input
                id="closingCosts"
                type="number"
                value={closingCosts}
                onChange={(e) => setClosingCosts(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="cashOut" className="text-slate-700 font-medium">Cash Out Amount (Optional)</Label>
            <Input
              id="cashOut"
              type="number"
              value={cashOut}
              onChange={(e) => setCashOut(Number(e.target.value))}
              className="border-slate-300 mt-1"
            />
            <p className="text-xs text-slate-500 mt-1">Additional cash to receive at closing</p>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <TrendingUp className="w-6 h-6 text-green-600 mr-3" />
            Refinance Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Key Results */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-slate-600 mb-2">Monthly Savings</h3>
              <div className={`text-4xl font-bold ${results.monthlySavings >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                {results.monthlySavings >= 0 ? '+' : ''}{formatCurrency(results.monthlySavings)}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-50 rounded-lg p-4 text-center">
              <h4 className="text-sm font-medium text-slate-600 mb-1">Current Payment</h4>
              <div className="text-2xl font-bold text-slate-900">{formatCurrency(currentPayment)}</div>
            </div>
            <div className="bg-blue-50 rounded-lg p-4 text-center">
              <h4 className="text-sm font-medium text-slate-600 mb-1">New Payment</h4>
              <div className="text-2xl font-bold text-blue-600">{formatCurrency(results.newPayment)}</div>
            </div>
          </div>

          {/* Detailed Analysis */}
          <div className="space-y-4">
            <h4 className="font-semibold text-slate-900">Refinance Analysis:</h4>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">New Loan Amount</span>
              <span className="font-medium">{formatCurrency(results.totalNewLoan)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Loan-to-Value Ratio</span>
              <span className={`font-medium ${results.loanToValue > 80 ? 'text-red-600' : 'text-green-600'}`}>
                {results.loanToValue.toFixed(1)}%
              </span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Break-Even Point</span>
              <span className="font-medium">
                {results.breakEvenMonths > 0 ? `${Math.ceil(results.breakEvenMonths)} months` : 'N/A'}
              </span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Total Interest Savings</span>
              <span className={`font-medium ${results.totalSavings >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                {results.totalSavings >= 0 ? '+' : ''}{formatCurrency(results.totalSavings)}
              </span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Closing Costs</span>
              <span className="font-medium text-red-600">-{formatCurrency(closingCosts)}</span>
            </div>
          </div>

          {/* Recommendations */}
          <div className={`rounded-lg p-4 ${results.monthlySavings > 200 ? 'bg-green-50 border border-green-200' : 
            results.monthlySavings > 0 ? 'bg-yellow-50 border border-yellow-200' : 'bg-red-50 border border-red-200'}`}>
            <h4 className="font-semibold mb-2">
              {results.monthlySavings > 200 ? '✅ Great Refinance Opportunity' :
               results.monthlySavings > 0 ? '⚠️ Moderate Savings Potential' : '❌ Refinancing May Not Be Beneficial'}
            </h4>
            <p className="text-sm">
              {results.monthlySavings > 200 ? 
                'Significant monthly savings make this refinance very attractive. Consider proceeding with the application.' :
               results.monthlySavings > 0 ? 
                'You\'ll save money monthly, but consider if the break-even period works for your timeline.' :
                'The new rate doesn\'t provide enough savings to justify the closing costs. Consider waiting for better rates.'}
            </p>
          </div>

          {results.loanToValue > 80 && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <p className="text-orange-800 text-sm">
                <strong>Note:</strong> Your loan-to-value ratio exceeds 80%. You may need to pay PMI or consider different loan options.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}