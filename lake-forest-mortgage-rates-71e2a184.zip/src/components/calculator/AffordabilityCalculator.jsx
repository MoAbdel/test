import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Home, DollarSign, Calculator } from "lucide-react";

export default function AffordabilityCalculator() {
  const [annualIncome, setAnnualIncome] = useState(100000);
  const [monthlyDebts, setMonthlyDebts] = useState(500);
  const [downPayment, setDownPayment] = useState(100000);
  const [interestRate, setInterestRate] = useState(6.875);
  const [loanTerm, setLoanTerm] = useState(30);
  const [propertyTaxRate, setPropertyTaxRate] = useState(1.25);
  const [homeInsurance, setHomeInsurance] = useState(100);

  const [results, setResults] = useState({
    maxHomePrice: 0,
    maxLoanAmount: 0,
    monthlyPayment: 0,
    dtiRatio: 0
  });

  useEffect(() => {
    calculateAffordability();
  }, [annualIncome, monthlyDebts, downPayment, interestRate, loanTerm, propertyTaxRate, homeInsurance]);

  const calculateAffordability = () => {
    const monthlyIncome = annualIncome / 12;
    const maxMonthlyPayment = monthlyIncome * 0.28; // 28% front-end DTI ratio
    const maxTotalDebt = monthlyIncome * 0.36; // 36% back-end DTI ratio
    const availableForHousing = Math.min(maxMonthlyPayment, maxTotalDebt - monthlyDebts);

    // Subtract property tax and insurance from available payment
    const availableForPI = availableForHousing - homeInsurance;
    
    // Calculate maximum loan amount using payment formula
    const monthlyRate = (interestRate / 100) / 12;
    const numberOfPayments = loanTerm * 12;
    
    let maxLoanAmount = 0;
    if (monthlyRate > 0) {
      maxLoanAmount = availableForPI * (Math.pow(1 + monthlyRate, numberOfPayments) - 1) / (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments));
    } else {
      maxLoanAmount = availableForPI * numberOfPayments;
    }

    const maxHomePrice = maxLoanAmount + downPayment;
    
    // Calculate property tax based on home price
    const monthlyPropertyTax = (maxHomePrice * (propertyTaxRate / 100)) / 12;
    
    // Adjust for property tax
    const adjustedAvailableForPI = availableForHousing - homeInsurance - monthlyPropertyTax;
    let adjustedMaxLoan = 0;
    
    if (monthlyRate > 0 && adjustedAvailableForPI > 0) {
      adjustedMaxLoan = adjustedAvailableForPI * (Math.pow(1 + monthlyRate, numberOfPayments) - 1) / (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments));
    } else if (adjustedAvailableForPI > 0) {
      adjustedMaxLoan = adjustedAvailableForPI * numberOfPayments;
    }

    const adjustedMaxHomePrice = adjustedMaxLoan + downPayment;
    
    // Calculate actual monthly payment for the max home price
    let monthlyPayment = 0;
    if (monthlyRate > 0) {
      monthlyPayment = adjustedMaxLoan * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    } else {
      monthlyPayment = adjustedMaxLoan / numberOfPayments;
    }

    const finalMonthlyPropertyTax = (adjustedMaxHomePrice * (propertyTaxRate / 100)) / 12;
    const totalMonthlyPayment = monthlyPayment + finalMonthlyPropertyTax + homeInsurance;
    const dtiRatio = ((totalMonthlyPayment + monthlyDebts) / monthlyIncome) * 100;

    setResults({
      maxHomePrice: Math.max(0, adjustedMaxHomePrice),
      maxLoanAmount: Math.max(0, adjustedMaxLoan),
      monthlyPayment: totalMonthlyPayment,
      dtiRatio
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Form */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Calculator className="w-6 h-6 text-blue-600 mr-3" />
            Financial Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="annualIncome" className="text-slate-700 font-medium">Annual Gross Income</Label>
            <Input
              id="annualIncome"
              type="number"
              value={annualIncome}
              onChange={(e) => setAnnualIncome(Number(e.target.value))}
              className="border-slate-300 mt-1"
            />
            <p className="text-xs text-slate-500 mt-1">Before taxes and deductions</p>
          </div>

          <div>
            <Label htmlFor="monthlyDebts" className="text-slate-700 font-medium">Monthly Debt Payments</Label>
            <Input
              id="monthlyDebts"
              type="number"
              value={monthlyDebts}
              onChange={(e) => setMonthlyDebts(Number(e.target.value))}
              className="border-slate-300 mt-1"
            />
            <p className="text-xs text-slate-500 mt-1">Credit cards, car loans, student loans, etc.</p>
          </div>

          <div>
            <Label htmlFor="downPayment" className="text-slate-700 font-medium">Available Down Payment</Label>
            <Input
              id="downPayment"
              type="number"
              value={downPayment}
              onChange={(e) => setDownPayment(Number(e.target.value))}
              className="border-slate-300 mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="interestRate" className="text-slate-700 font-medium">Interest Rate (%)</Label>
              <Input
                id="interestRate"
                type="number"
                step="0.001"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="loanTerm" className="text-slate-700 font-medium">Loan Term</Label>
              <Select value={loanTerm.toString()} onValueChange={(value) => setLoanTerm(Number(value))}>
                <SelectTrigger className="border-slate-300 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 Years</SelectItem>
                  <SelectItem value="20">20 Years</SelectItem>
                  <SelectItem value="25">25 Years</SelectItem>
                  <SelectItem value="30">30 Years</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="propertyTaxRate" className="text-slate-700 font-medium">Property Tax Rate (%)</Label>
              <Input
                id="propertyTaxRate"
                type="number"
                step="0.01"
                value={propertyTaxRate}
                onChange={(e) => setPropertyTaxRate(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
              <p className="text-xs text-slate-500 mt-1">Average in Orange County: 1.25%</p>
            </div>
            <div>
              <Label htmlFor="homeInsurance" className="text-slate-700 font-medium">Monthly Home Insurance</Label>
              <Input
                id="homeInsurance"
                type="number"
                value={homeInsurance}
                onChange={(e) => setHomeInsurance(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Home className="w-6 h-6 text-green-600 mr-3" />
            What You Can Afford
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Key Results */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-slate-600 mb-2">Maximum Home Price</h3>
              <div className="text-4xl font-bold text-slate-900">
                {formatCurrency(results.maxHomePrice)}
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-slate-600 mb-2">Monthly Payment (PITI)</h3>
              <div className="text-3xl font-bold text-slate-900">
                {formatCurrency(results.monthlyPayment)}
              </div>
            </div>
          </div>

          {/* Affordability Breakdown */}
          <div className="space-y-4">
            <h4 className="font-semibold text-slate-900">Affordability Breakdown:</h4>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Maximum Loan Amount</span>
              <span className="font-medium">{formatCurrency(results.maxLoanAmount)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Down Payment</span>
              <span className="font-medium">{formatCurrency(downPayment)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Down Payment %</span>
              <span className="font-medium">
                {results.maxHomePrice > 0 ? ((downPayment / results.maxHomePrice) * 100).toFixed(1) : 0}%
              </span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Total Debt-to-Income Ratio</span>
              <span className={`font-medium ${results.dtiRatio > 36 ? 'text-red-600' : 'text-green-600'}`}>
                {results.dtiRatio.toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Guidelines */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-semibold text-slate-900 mb-3">Affordability Guidelines:</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Monthly Gross Income:</span>
                <span className="font-medium">{formatCurrency(annualIncome / 12)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Max Housing Payment (28%):</span>
                <span className="font-medium">{formatCurrency((annualIncome / 12) * 0.28)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Max Total Debt (36%):</span>
                <span className="font-medium">{formatCurrency((annualIncome / 12) * 0.36)}</span>
              </div>
            </div>
          </div>

          {results.dtiRatio > 36 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800 text-sm">
                <strong>Note:</strong> Your debt-to-income ratio exceeds 36%. Consider paying down debts or increasing your down payment to improve affordability.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}