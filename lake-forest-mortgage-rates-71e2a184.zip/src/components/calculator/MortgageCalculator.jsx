import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DollarSign, Home, Calculator, TrendingUp } from "lucide-react";

export default function MortgageCalculator() {
  const [loanAmount, setLoanAmount] = useState(600000);
  const [downPayment, setDownPayment] = useState(120000);
  const [interestRate, setInterestRate] = useState(6.875);
  const [loanTerm, setLoanTerm] = useState(30);
  const [propertyTax, setPropertyTax] = useState(7500);
  const [homeInsurance, setHomeInsurance] = useState(1200);
  const [pmi, setPmi] = useState(0);
  const [hoaDues, setHoaDues] = useState(0);

  const [results, setResults] = useState({
    monthlyPayment: 0,
    totalInterest: 0,
    totalPayment: 0,
    monthlyPITI: 0
  });

  useEffect(() => {
    calculatePayment();
  }, [loanAmount, downPayment, interestRate, loanTerm, propertyTax, homeInsurance, pmi, hoaDues]);

  const calculatePayment = () => {
    const principal = loanAmount - downPayment;
    const monthlyRate = (interestRate / 100) / 12;
    const numberOfPayments = loanTerm * 12;

    let monthlyPayment = 0;
    if (monthlyRate > 0) {
      monthlyPayment = principal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    } else {
      monthlyPayment = principal / numberOfPayments;
    }

    const totalPayment = monthlyPayment * numberOfPayments;
    const totalInterest = totalPayment - principal;

    // Calculate PMI if down payment is less than 20%
    const downPaymentPercent = (downPayment / loanAmount) * 100;
    let monthlyPMI = pmi;
    if (downPaymentPercent < 20 && pmi === 0) {
      monthlyPMI = (principal * 0.005) / 12; // 0.5% annually
    }

    const monthlyPITI = monthlyPayment + (propertyTax / 12) + (homeInsurance / 12) + monthlyPMI + (hoaDues / 12);

    setResults({
      monthlyPayment,
      totalInterest,
      totalPayment,
      monthlyPITI
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Form */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Calculator className="w-6 h-6 text-blue-600 mr-3" />
            Loan Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="loanAmount" className="text-slate-700 font-medium">Home Price</Label>
              <Input
                id="loanAmount"
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="downPayment" className="text-slate-700 font-medium">Down Payment</Label>
              <Input
                id="downPayment"
                type="number"
                value={downPayment}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="interestRate" className="text-slate-700 font-medium">Interest Rate (%)</Label>
              <Input
                id="interestRate"
                type="number"
                step="0.001"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="loanTerm" className="text-slate-700 font-medium">Loan Term</Label>
              <Select value={loanTerm.toString()} onValueChange={(value) => setLoanTerm(Number(value))}>
                <SelectTrigger className="border-slate-300 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 Years</SelectItem>
                  <SelectItem value="20">20 Years</SelectItem>
                  <SelectItem value="25">25 Years</SelectItem>
                  <SelectItem value="30">30 Years</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="propertyTax" className="text-slate-700 font-medium">Annual Property Tax</Label>
              <Input
                id="propertyTax"
                type="number"
                value={propertyTax}
                onChange={(e) => setPropertyTax(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="homeInsurance" className="text-slate-700 font-medium">Annual Home Insurance</Label>
              <Input
                id="homeInsurance"
                type="number"
                value={homeInsurance}
                onChange={(e) => setHomeInsurance(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pmi" className="text-slate-700 font-medium">Monthly PMI</Label>
              <Input
                id="pmi"
                type="number"
                value={pmi}
                onChange={(e) => setPmi(Number(e.target.value))}
                className="border-slate-300 mt-1"
                placeholder="Auto-calculated if needed"
              />
            </div>
            <div>
              <Label htmlFor="hoaDues" className="text-slate-700 font-medium">Annual HOA Dues</Label>
              <Input
                id="hoaDues"
                type="number"
                value={hoaDues}
                onChange={(e) => setHoaDues(Number(e.target.value))}
                className="border-slate-300 mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card className="shadow-lg border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <DollarSign className="w-6 h-6 text-green-600 mr-3" />
            Payment Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Key Results */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-slate-600 mb-2">Monthly Payment (Principal & Interest)</h3>
              <div className="text-4xl font-bold text-slate-900">
                {formatCurrency(results.monthlyPayment)}
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-slate-600 mb-2">Total Monthly Payment (PITI + HOA)</h3>
              <div className="text-3xl font-bold text-slate-900">
                {formatCurrency(results.monthlyPITI)}
              </div>
            </div>
          </div>

          {/* Payment Breakdown */}
          <div className="space-y-4">
            <h4 className="font-semibold text-slate-900">Monthly Payment Breakdown:</h4>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Principal & Interest</span>
              <span className="font-medium">{formatCurrency(results.monthlyPayment)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Property Tax</span>
              <span className="font-medium">{formatCurrency(propertyTax / 12)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-slate-200">
              <span className="text-slate-600">Home Insurance</span>
              <span className="font-medium">{formatCurrency(homeInsurance / 12)}</span>
            </div>
            
            {((downPayment / loanAmount) * 100 < 20 || pmi > 0) && (
              <div className="flex justify-between items-center py-2 border-b border-slate-200">
                <span className="text-slate-600">PMI</span>
                <span className="font-medium">{formatCurrency(pmi || ((loanAmount - downPayment) * 0.005) / 12)}</span>
              </div>
            )}
            
            {hoaDues > 0 && (
              <div className="flex justify-between items-center py-2 border-b border-slate-200">
                <span className="text-slate-600">HOA Dues</span>
                <span className="font-medium">{formatCurrency(hoaDues / 12)}</span>
              </div>
            )}
          </div>

          {/* Loan Summary */}
          <div className="bg-slate-50 rounded-lg p-4">
            <h4 className="font-semibold text-slate-900 mb-3">Loan Summary:</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Loan Amount:</span>
                <span className="font-medium">{formatCurrency(loanAmount - downPayment)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Total Interest Paid:</span>
                <span className="font-medium">{formatCurrency(results.totalInterest)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Total Paid Over Life:</span>
                <span className="font-medium">{formatCurrency(results.totalPayment)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Down Payment %:</span>
                <span className="font-medium">{((downPayment / loanAmount) * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}