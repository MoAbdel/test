
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Home, DollarSign, Calendar, ArrowRight } from "lucide-react"; // Changed MapPin to Calendar
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { MarketInsight } from "@/api/entities"; // Added import for MarketInsight

export default function LocalMarketInsights() {
  const [marketData, setMarketData] = useState([]); // Initialized marketData with useState

  // useEffect to fetch market insights when the component mounts
  useEffect(() => {
    const fetchInsights = async () => {
      try {
        const insights = await MarketInsight.list('display_order'); // Fetch data
        setMarketData(insights); // Update state with fetched data
      } catch (error) {
        console.error("Failed to fetch market insights:", error);
        // Optionally, handle error state or display a fallback
      }
    };
    fetchInsights();
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge className="bg-green-100 text-green-800 mb-4">
            <Calendar className="w-4 h-4 mr-1" /> {/* Changed icon from MapPin to Calendar */}
            Orange County Market Update
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Local Housing Market Insights
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Stay informed about Orange County housing trends. 
            Understanding the market helps you make better financing decisions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Render market data dynamically from state */}
          {marketData.map((data, index) => (
            <Card key={index} className="hover:shadow-lg transition-all duration-300 border-slate-200">
              <CardContent className="p-6 text-center">
                <div className="mb-4">
                  <div className="text-3xl font-bold text-slate-900 mb-1">{data.value}</div>
                  <div className="text-sm font-medium text-slate-600">{data.metric}</div>
                </div>
                
                <div className={`flex items-center justify-center space-x-1 text-sm font-medium mb-2 ${
                  data.trend === 'up' ? 'text-green-600' : 
                  data.trend === 'down' ? 'text-red-500' : 'text-slate-600'
                }`}>
                  {data.trend === 'up' && <TrendingUp className="w-4 h-4" />}
                  {/* Note: Inverted TrendingUp icon for 'down' trend */}
                  {data.trend === 'down' && <TrendingUp className="w-4 h-4 transform rotate-180" />} 
                  <span>{data.change}</span>
                </div>
                
                <p className="text-xs text-slate-500">{data.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Orange County Highlights */}
          <Card className="border-slate-200 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <Home className="w-6 h-6 text-blue-600 mr-3" />
                Why Orange County is a Great Investment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Top-Rated Schools</h4>
                  <p className="text-slate-600 text-sm">Multiple highly-rated school districts throughout the county</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Prime Location</h4>
                  <p className="text-slate-600 text-sm">Easy access to beaches, mountains, and major employment centers</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Strong Property Values</h4>
                  <p className="text-slate-600 text-sm">Consistent appreciation and desirable communities throughout OC</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financing Programs */}
          <Card className="border-slate-200 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <DollarSign className="w-6 h-6 text-green-600 mr-3" />
                Special Programs Available
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Refinancing Specialists</h4>
                  <p className="text-slate-600 text-sm">Cash-out, rate & term, and streamline refinance programs with competitive rates</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Non-QM Loan Programs</h4>
                  <p className="text-slate-600 text-sm">Bank statement loans, asset-based financing, and alternative documentation options</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-900">Jumbo Loan Specialists</h4>
                  <p className="text-slate-600 text-sm">Competitive rates for loans above conventional limits</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-sm text-slate-500 mb-6">
            Market data updated periodically. Sources may include: MLS, Orange County Association of Realtors, CoreLogic
          </p>
          
          <Link to={createPageUrl("Programs")}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
              Explore Loan Programs
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
